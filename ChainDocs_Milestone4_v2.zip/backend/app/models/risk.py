from sqlalchemy import Column, Integer, Float
from app.database import Base

class RiskScore(Base):
    __tablename__ = "risk_scores"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    score = Column(Float)
