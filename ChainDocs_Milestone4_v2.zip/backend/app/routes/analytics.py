from fastapi import APIRouter
from app.database import SessionLocal
from app.models.risk import RiskScore

router = APIRouter(prefix="/analytics")

@router.get("/calculate/{user_id}")
def calculate_risk(user_id: int):
    db = SessionLocal()

    # Basic risk logic example
    base_score = 25
    score = min(base_score + (user_id * 3), 100)

    risk = RiskScore(user_id=user_id, score=score)
    db.add(risk)
    db.commit()

    return {"user_id": user_id, "risk_score": score}


@router.get("/summary")
def summary():
    db = SessionLocal()
    records = db.query(RiskScore).all()

    total = len(records)
    avg = sum(r.score for r in records) / total if total > 0 else 0

    return {
        "total_risk_records": total,
        "average_risk_score": avg
    }
