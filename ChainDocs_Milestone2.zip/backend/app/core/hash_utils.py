import hashlib

def generate_hash(data: bytes):
    return hashlib.sha256(data).hexdigest()
