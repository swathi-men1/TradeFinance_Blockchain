from sqlalchemy import Column, Integer, String
from app.database import Base

class LedgerEntry(Base):
    __tablename__ = "ledger_entries"
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer)
    action = Column(String)
