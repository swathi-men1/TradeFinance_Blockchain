from sqlalchemy import Column, Integer, String
from app.database import Base

class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True)
    doc_type = Column(String)
    doc_number = Column(String)
    file_path = Column(String)
    hash = Column(String)
