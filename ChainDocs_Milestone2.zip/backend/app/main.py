from fastapi import FastAPI
from app.routes import documents, ledger

app = FastAPI(title="ChainDocs Milestone 2")
app.include_router(documents.router)
app.include_router(ledger.router)
