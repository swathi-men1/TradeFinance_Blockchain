from fastapi import APIRouter
from app.database import SessionLocal
from app.models.ledger import LedgerEntry

router = APIRouter(prefix="/ledger")

@router.get("/{doc_id}")
def get_ledger(doc_id: int):
    db = SessionLocal()
    return db.query(LedgerEntry).filter(LedgerEntry.document_id == doc_id).all()
