from fastapi import APIRouter, UploadFile, File
from app.database import SessionLocal, engine, Base
from app.models.document import Document
from app.models.ledger import LedgerEntry
from app.core.hash_utils import generate_hash
import os

router = APIRouter(prefix="/documents")
Base.metadata.create_all(bind=engine)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/upload")
async def upload(doc_type: str, doc_number: str, file: UploadFile = File(...)):
    db = SessionLocal()
    content = await file.read()
    h = generate_hash(content)

    path = f"{UPLOAD_DIR}/{file.filename}"
    with open(path, "wb") as f:
        f.write(content)

    doc = Document(doc_type=doc_type, doc_number=doc_number, file_path=path, hash=h)
    db.add(doc)
    db.commit()
    db.refresh(doc)

    db.add(LedgerEntry(document_id=doc.id, action="ISSUED"))
    db.commit()

    return {"doc_id": doc.id, "hash": h}
