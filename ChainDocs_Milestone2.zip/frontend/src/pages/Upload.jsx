import { useState } from "react";
import axios from "axios";

export default function Upload(){
  const [file,setFile]=useState(null);

  const upload = async () => {
    const f = new FormData();
    f.append("file", file);
    await axios.post(
      "http://127.0.0.1:8000/documents/upload?doc_type=INVOICE&doc_number=INV001",
      f
    );
    alert("Uploaded");
  };

  return (
    <div>
      <h2>Upload Document</h2>
      <input type="file" onChange={e=>setFile(e.target.files[0])} />
      <button onClick={upload}>Upload</button>
    </div>
  );
}
