from fastapi import FastAPI
from app.database import Base, engine
from app.routes import trade, integrity

Base.metadata.create_all(bind=engine)

app = FastAPI(title="ChainDocs Milestone 3 - Trade & Integrity")
app.include_router(trade.router)
app.include_router(integrity.router)
