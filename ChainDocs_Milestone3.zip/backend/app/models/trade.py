from sqlalchemy import Column, Integer, Float, String
from app.database import Base

class TradeTransaction(Base):
    __tablename__ = "trade_transactions"
    id = Column(Integer, primary_key=True)
    buyer_id = Column(Integer)
    seller_id = Column(Integer)
    amount = Column(Float)
    currency = Column(String)
    status = Column(String, default="pending")
