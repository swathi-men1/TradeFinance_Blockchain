from fastapi import APIRouter
from app.database import SessionLocal, Base, engine
from app.models.trade import TradeTransaction
from app.models.ledger import LedgerEntry

router = APIRouter(prefix="/trades")
Base.metadata.create_all(bind=engine)

@router.post("/create")
def create_trade(buyer_id: int, seller_id: int, amount: float, currency: str):
    db = SessionLocal()
    trade = TradeTransaction(
        buyer_id=buyer_id,
        seller_id=seller_id,
        amount=amount,
        currency=currency
    )
    db.add(trade)
    db.commit()
    db.refresh(trade)

    db.add(LedgerEntry(document_id=trade.id, action="TRADE_CREATED"))
    db.commit()

    return trade

@router.put("/update/{trade_id}")
def update_status(trade_id: int, status: str):
    db = SessionLocal()
    trade = db.query(TradeTransaction).filter_by(id=trade_id).first()
    trade.status = status
    db.commit()

    db.add(LedgerEntry(document_id=trade.id, action=f"STATUS_{status.upper()}"))
    db.commit()

    return {"message": "Trade updated"}
