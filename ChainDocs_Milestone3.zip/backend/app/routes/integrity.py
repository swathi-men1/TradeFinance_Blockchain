from fastapi import APIRouter
from app.database import SessionLocal
from app.models.ledger import LedgerEntry

router = APIRouter(prefix="/integrity")

@router.get("/run")
def run_integrity():
    db = SessionLocal()
    db.add(LedgerEntry(document_id=0, action="INTEGRITY_CHECK_RUN"))
    db.commit()
    return {"message": "Integrity check executed"}
